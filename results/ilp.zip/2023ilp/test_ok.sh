time python3 main.py -e subset_sum_double_and_prod -d 4 --aggregates "sum(el/2)" "sum(el/2)" --arithm add mul sub --verbose=2 --variables=5
